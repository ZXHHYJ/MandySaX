package com.china.MandiSa.V;

import android.content.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.*;
import java.util.*;

public class PopWindows
{
    public static void a(final View view)
	{
        List<String> dataList = new ArrayList<>();
        /*for(int i = 0; i < 13; i++){
		 dataList.add(String.valueOf(i));
		 }*/
		dataList.add("添加书签");
		dataList.add("书签历史");
		dataList.add("下载");
		dataList.add("隐身");
		dataList.add("工具箱");
		dataList.add("设置");
		final PopupWindowList mPopupWindowList = new PopupWindowList(view.getContext());
        mPopupWindowList.setAnchorView(view);
        mPopupWindowList.setItemData(dataList);
        mPopupWindowList.setModal(true);
        mPopupWindowList.show();
        mPopupWindowList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View views, int position, long id)
				{
					switch (position)
					{
						case 0:
							break;
						case 1:
							break;
						case 2:
							break;
						case 3:
							break;
						case 4:
							b(view);
							break;
						case 5:
							Intent intent = new Intent(com.china.MandiSa.MainActivity.e, SettingActivity.class);
							com.china.MandiSa.MainActivity.e.startActivity(intent);
							break;
					}
					mPopupWindowList.hide();
				}
			});
	}

	public static void b(View view)
	{
		List<String> dataList = new ArrayList<>();
		dataList.add("查看源码");
		dataList.add("页内查找");
		dataList.add("保存网页");
        final PopupWindowList mPopupWindowList = new PopupWindowList(view.getContext());
        mPopupWindowList.setAnchorView(view);
        mPopupWindowList.setItemData(dataList);
        mPopupWindowList.setModal(true);
        mPopupWindowList.show();
        mPopupWindowList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View views, int position, long id)
				{
					switch (position)
					{
						case 0:
							Intent intent2 = new Intent(com.china.MandiSa.MainActivity.e, WebActivity.class);
							com.china.MandiSa.MainActivity.e.startActivity(intent2);
							break;
						case 1:
							break;
						case 2:
							break;
						case 3:
							break;
						case 4:
							break;
						case 5:
							break;
					}
					mPopupWindowList.hide();
				}
			});
	}
}
