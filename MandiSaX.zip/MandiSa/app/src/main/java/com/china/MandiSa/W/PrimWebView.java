package com.china.MandiSa.W;

import android.animation.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.icu.text.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.util.*;
import android.view.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import com.china.MandiSa.*;
import com.china.MandiSa.X.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.china.MandiSa.Cc.*;

/**
 * Created by guoshuyu on 2017/6/16.
 */

public class PrimWebView extends WebView
{
	public static final int REQUEST_CODE_LOLIPOP = 1;
	public static final int RESULT_CODE_ICE_CREAM = 2;
    public ValueCallback<Uri[]> mFilePathCallback;
    public String mCameraPhotoPath;
	public static boolean isDayTheme = true;
	public static boolean isJs = true;
	public static boolean isDom = true;
	public static boolean isGps = false;
	public static boolean isImg = true;
	public WebSettings webSetting = this.getSettings();
	public static int currentProgress;

	public static PrimWebView a;

	public ProgressBar progressbar;

    ActionMode mActionMode;

    List<String> mActionList = new ArrayList<>();

    ActionSelectListener mActionSelectListener;

	private TranslateAnimation animation1,animation2;

	private ViewTreeObserver vto1;

	private float x1;

	private float y1;

	private float x2;

	private float y2;

	public boolean DayTheme()
	{
		isDayTheme = !isDayTheme;
		setDayOrNight(isDayTheme);
		SpUtils.putBoolean(getContext(), "isDayTheme", isDayTheme);
		return isDayTheme;
	}

	private void setDayOrNight(boolean isDayTheme)
	{
		// TODO: Implement this method
	}

    public boolean isJs()
	{
		isJs = !isJs;
        webSetting.setJavaScriptEnabled(isJs);
		SpUtils.putBoolean(getContext(), "isJs", isJs);
		return isJs;
	}
	public boolean isDom()
	{
		isDom = !isDom;
        webSetting.setDomStorageEnabled(isDom);
		SpUtils.putBoolean(getContext(), "isDom", isDom);
		return isDom;
	}
	public boolean isImg()
	{
		isImg = !isImg;
		SpUtils.putBoolean(getContext(), "isImg", isImg);
		return isImg;
	}
	public boolean isGps()
	{
		isGps = !isGps;
        webSetting.setBlockNetworkImage(isGps);
		SpUtils.putBoolean(getContext(), "isGps", isGps);
		this.reload();
		return isGps;
	}

	@Override  
    public boolean onTouchEvent(MotionEvent event)
	{  
        //继承了Activity的onTouchEvent方法，直接监听点击事件  
        if (event.getAction() == MotionEvent.ACTION_DOWN)
		{  
            //当手指按下的时候  
			x1 = event.getX();  
			y1 = event.getY();  
        }  
        if (event.getAction() == MotionEvent.ACTION_UP)
		{  
            //当手指离开的时候  
			x2 = event.getX();  
			y2 = event.getY();  
			if (y1 - y2 > 50)
			{  
				//ToastUtil.getInstance().showToast("向下滑",getContext());
				if (com.china.MandiSa.MainActivity.c.getVisibility() == 0 )
				{
					if (com.china.MandiSa.Bug.AndroidBug5497Workaround.ifLCD())
					{
						if(com.china.MandiSa.Bug.AndroidBug5497Workaround.ifKeyboard()==false)
						{
						com.china.MandiSa.MainActivity.c.startAnimation(animation1);
						com.china.MandiSa.MainActivity.c.setVisibility(8);
						}
					}
				}
            }
			else if (y2 - y1 > 50)
			{  
				//ToastUtil.getInstance().showToast("向上滑",getContext());
				if (com.china.MandiSa.MainActivity.c.getVisibility() == 8 )
				{
					if (com.china.MandiSa.Bug.AndroidBug5497Workaround.ifLCD())
					{
						if(com.china.MandiSa.Bug.AndroidBug5497Workaround.ifKeyboard()==false)
						{
						com.china.MandiSa.MainActivity.c.startAnimation(animation2);
						com.china.MandiSa.MainActivity.c.setVisibility(0);
						}
					}
				}
            }
			else if (x1 - x2 > 50)
			{  
                //Toast.makeText(MainActivity.this, "向左滑", Toast.LENGTH_SHORT).show();  
            }
			else if (x2 - x1 > 50)
			{  
                //Toast.makeText(MainActivity.this, "向右滑", Toast.LENGTH_SHORT).show();  
            }  
        }  
        return super.onTouchEvent(event);  
    }  


    public PrimWebView(Context context)
	{
        super(context);
		a = this;
		progressbar = new ProgressBar(context, null, android.R.style.Widget_ProgressBar_Horizontal);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 8);
        Drawable drawable = getContext().getResources().getDrawable(R.drawable.default_drawable_indicator);
        progressbar.setProgressDrawable(drawable);
        progressbar.setLayoutParams(layoutParams);
        addView(progressbar);
		initSetting();
		setHorizontalFadingEdgeEnabled(false);
	    setOverScrollMode(OVER_SCROLL_NEVER);
		vto1 = com.china.MandiSa.MainActivity.c.getViewTreeObserver();
		vto1.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener()
			{
				public boolean onPreDraw()
				{
					animation1 = new TranslateAnimation(0, 0, 0, com.china.MandiSa.MainActivity.c.getMeasuredHeight());
					animation1.setDuration(300);
					animation1.setFillAfter(false);
					animation2 = new TranslateAnimation(0, 0, com.china.MandiSa.MainActivity.c.getMeasuredHeight(), 0);
					animation2.setDuration(300);
					animation2.setFillAfter(true);
					return true;
				}
			});
    }

	private void initSetting()
	{
		// TODO: Implement this method
		// 允许调试
        if (Build.VERSION.SDK_INT >= 19)
		{
            this.setWebContentsDebuggingEnabled(true);
        }
        // 开启JS
        webSetting.setJavaScriptEnabled(true);
        // 开启JS能打开窗口
        webSetting.setJavaScriptCanOpenWindowsAutomatically(true);
        // 开启缓存
        webSetting.setCacheMode(WebSettings.LOAD_DEFAULT);
        // 自适应屏幕
        webSetting.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);  
		webSetting.setUseWideViewPort(true);
		webSetting.setLoadWithOverviewMode(true);
        // 支持缩放
        webSetting.setSupportZoom(true);
        // 启用内置缩放控件
        webSetting.setBuiltInZoomControls(true);
        // 隐藏缩放控件
        webSetting.setDisplayZoomControls(false);
        // 开启访问文件
        webSetting.setAllowFileAccess(true);
        // 开启数据库
        webSetting.setDatabaseEnabled(true);
        // 开启localStorage
        webSetting.setDomStorageEnabled(true);
        // 开启定位
        webSetting.setGeolocationEnabled(true);
        // 支持多窗口
        webSetting.setSupportMultipleWindows(true);
        // 允许跨域
		webSetting.setAllowUniversalAccessFromFileURLs(true);

		WebSettings.ZoomDensity ZoomDensity = WebSettings.ZoomDensity.MEDIUM ;
		int screenDensity = getResources().getDisplayMetrics().densityDpi ;   
		switch (screenDensity)
		{   

			case DisplayMetrics.DENSITY_LOW :
				ZoomDensity = WebSettings.ZoomDensity.CLOSE;
				break;   

			case DisplayMetrics.DENSITY_MEDIUM:   
				ZoomDensity = WebSettings.ZoomDensity.CLOSE;   
				break;   

			case DisplayMetrics.DENSITY_HIGH:   
				ZoomDensity = WebSettings.ZoomDensity.FAR;   
				break ;   
		}
	    webSetting.setDefaultZoom(ZoomDensity);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
		{
            webSetting.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

		if (SpUtils.getBoolean(getContext(), "isDayTheme", true))
		{
			setDayOrNight(true);
			isDayTheme = true;
		}
		else
		{
			setDayOrNight(false);
			isDayTheme = false;
		}
		if (SpUtils.getBoolean(getContext(), "isJs", true))
		{
			webSetting.setJavaScriptEnabled(true);
			isJs = true;
		}
		else
		{
			webSetting.setJavaScriptEnabled(false);
			isJs = false;
		}
		if (SpUtils.getBoolean(getContext(), "isDom", true))
		{
			webSetting.setDomStorageEnabled(true);
			isDom = true;
		}
		else
		{
			webSetting.setDomStorageEnabled(false);
			isDom = false;
		}
		if (SpUtils.getBoolean(getContext(), "isGps", true))
		{
			webSetting.setGeolocationEnabled(true);
			isGps = true;
		}
		else
		{
			webSetting.setGeolocationEnabled(false);
			isGps = false;
		}
		if (SpUtils.getBoolean(getContext(), "isImg", true))
		{
			isImg = true;
		}
		else
		{
			isImg = false;
		}

		List<String> list = new ArrayList<>();
        list.add("Item1");
        list.add("Item2");
        list.add("APIWeb");

        //设置item
        setActionList(list);

        //链接js注入接口，使能选中返回数据
        linkJSInterface();

	    setActionSelectListener(new ActionSelectListener() {
				@Override
				public void onClick(String title, String selectText)
				{
					if (title.equals("APIWeb"))
					{
						//Intent intent = new Intent(MainActivity.this, APIWebViewActivity.class);
						//startActivity(intent);
						return;
					}
					//Toast.makeText(MainActivity.this, "Click Item: " + title + "。\n\nValue: " + selectText, Toast.LENGTH_LONG).show();
				}
			});

		setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event)
				{
					v.requestFocus();			
					return false;
				}
			});

		setWebChromeClient(new WebChromeClient()
			{
				private void openFileChooser(String type)
				{
					Intent i = new Intent(Intent.ACTION_GET_CONTENT);
					i.addCategory(Intent.CATEGORY_OPENABLE);
					i.setType(type);
					com.china.MandiSa.MainActivity.e.startActivityForResult(Intent.createChooser(i, com.china.MandiSa.MainActivity.e.getString(R.string.file_chooser)), RESULT_CODE_ICE_CREAM);
				}

				private void onShowFileChooser(Intent cameraIntent)
				{
					Intent selectionIntent = new Intent(Intent.ACTION_PICK, null);
					selectionIntent.setType("image/*");
					Intent[] intentArray;
					if (cameraIntent != null)
					{
						intentArray = new Intent[]{cameraIntent};
					}
					else
					{
						intentArray = new Intent[0];
					}
					Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
					chooserIntent.putExtra(Intent.EXTRA_TITLE, com.china.MandiSa.MainActivity.e.getString(R.string.file_chooser));
					chooserIntent.putExtra(Intent.EXTRA_INTENT, selectionIntent);
					chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
					com.china.MandiSa.MainActivity.e.startActivityForResult(chooserIntent, REQUEST_CODE_LOLIPOP);
				}

				public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams)
				{
					if (mFilePathCallback != null)
					{
						mFilePathCallback.onReceiveValue(null);
					}
					mFilePathCallback = filePathCallback;

					Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
					if (takePictureIntent.resolveActivity(com.china.MandiSa.MainActivity.e.getApplication().getPackageManager()) != null)
					{
						File photoFile = null;
						try
						{
							photoFile = createImageFile();
							takePictureIntent.putExtra("PhotoPath", mCameraPhotoPath);
						}
						catch (IOException ex)
						{
							ex.printStackTrace();
						}

						if (photoFile != null)
						{
							mCameraPhotoPath = "file:" + photoFile.getAbsolutePath();
							takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
						}
						else
						{
							takePictureIntent = null;
						}
					}
					onShowFileChooser(takePictureIntent);
					return true;
				}

				private File createImageFile() throws IOException
				{
					// Create an imae file name
					String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
					String imageFileName = "JPEG_" + timeStamp + "_";
					File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
					File imageFile = File.createTempFile(imageFileName, ".jpg", storageDir);
					return imageFile;
				}

				@Override
				public void onProgressChanged(WebView view, int newProgress)
				{
					super.onProgressChanged(view, newProgress);
					PrimWebView.currentProgress = PrimWebView.a.progressbar.getProgress();
					PrimWebView.startProgressAnimation(newProgress);
				}

				@Override
				public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg)
				{
					PrimWebView webView = new PrimWebView(com.china.MandiSa.MainActivity.e.getApplication());
					com.china.MandiSa.MainActivity.e.webViewLayout.removeAllViews();
					com.china.MandiSa.MainActivity.e.webViewLayout.addView(webView);
					com.china.MandiSa.MainActivity.e.list_webView.add(webView);
					com.china.MandiSa.MainActivity.e.currentPage = com.china.MandiSa.MainActivity.e.list_webView.size() - 1;
					com.china.MandiSa.MainActivity.e.button_page.setText(com.china.MandiSa.MainActivity.e.list_webView.size() + "");
					WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
					transport.setWebView(webView);
					resultMsg.sendToTarget();
					return isUserGesture;
				}
			});
        setWebViewClient(new WebViewClient() {

				@Override
				public void onPageStarted(WebView view, String url, Bitmap favicon)
				{
					PrimWebView.a.progressbar.setAlpha(1.0f);
				}

				@Override
				public boolean shouldOverrideUrlLoading(final WebView view, final String url)
				{
					if (!url.startsWith("http"))
					{
						Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
						boolean isInstall = com.china.MandiSa.MainActivity.e.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY).size() > 0;
						if (isInstall)
						{
							com.china.MandiSa.MainActivity.e.startActivity(intent);
						}
						return true;
					}
					SpUtils.putString(com.china.MandiSa.MainActivity.e.getApplicationContext(), "url", SpUtils.getString(com.china.MandiSa.MainActivity.e.getApplicationContext(), "url") + "|" + url);
                    if (url.contains("http://") || url.contains("https://"))
					{
                        return false;
                    }
                    return true;
				}
				@Override
				public void onPageFinished(WebView view, String url)
				{
					super.onPageFinished(view, url);			
					PrimWebView.startDismissAnimation(PrimWebView.a.progressbar.getProgress());
					//图片宽度超出父元素适应父元素
					if (isImg)
					{
						String js = "javascript:var imgs=document.getElementsByTagName('img');for(var i=0;i<imgs.length;i++){if(imgs[i].parentNode.clientWidth > 0){if(imgs[i].clientWidth>imgs[i].parentNode.clientWidth){imgs[i].width=imgs[i].parentNode.clientWidth;}}}";
						view.loadUrl(js);
					}
				}
			});
	}

	public static boolean isHttpUrl(String urls)
	{
        boolean isUrl;
        // 判断是否是网址的正则表达式
        String regex = "(((https|http)?://)?([a-z0-9]+[.])|(www.))"
			+ "\\w+[.|\\/]([a-z0-9]{0,})?[[.]([a-z0-9]{0,})]+((/[\\S&&[^,;\u4E00-\u9FA5]]+)+)?([.][a-z0-9]{0,}+|/?)";

        Pattern pat = Pattern.compile(regex.trim());
        Matcher mat = pat.matcher(urls.trim());
        isUrl = mat.matches();
        return isUrl;
    }

	public static void startProgressAnimation(int newProgress)
    {
        ObjectAnimator animator = ObjectAnimator.ofInt(a.progressbar, "progress", a.currentProgress, newProgress);
        animator.setDuration(300);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.start();
    }

    /**
     * progressBar消失动画
     */
    public static  void startDismissAnimation(final int progress)
    {
        ObjectAnimator anim = ObjectAnimator.ofFloat(a.progressbar, "alpha", 1.0f, 0.0f);
        anim.setDuration(1350);  // 动画时长
        anim.setInterpolator(new DecelerateInterpolator());     // 减速
        // 关键, 添加动画进度监听器
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator)
                {
                    float fraction = valueAnimator.getAnimatedFraction();      // 0.0f ~ 1.0f
                    int offset = 100 - progress;
                    a.progressbar.setProgress((int) (progress + offset * fraction));
                }
            });

        anim.addListener(new AnimatorListenerAdapter() {

                @Override
                public void onAnimationEnd(Animator animation)
                {
                    // 动画结束
                    a.progressbar.setProgress(0);
                }
            });
        anim.start();
    }


    /**
     * 处理item，处理点击
     * @param actionMode
     */
    private ActionMode resolveActionMode(ActionMode actionMode)
	{
        if (actionMode != null)
		{
            final Menu menu = actionMode.getMenu();
            mActionMode = actionMode;
            menu.clear();
            for (int i = 0; i < mActionList.size(); i++)
			{
                menu.add(mActionList.get(i));
            }
            for (int i = 0; i < menu.size(); i++)
			{
                MenuItem menuItem = menu.getItem(i);
                menuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
						@Override
						public boolean onMenuItemClick(MenuItem item)
						{
							getSelectedData((String) item.getTitle());
							releaseAction();
							return true;
						}
					});
            }
        }
        mActionMode = actionMode;
        return actionMode;
    }

    @Override
    public ActionMode startActionMode(ActionMode.Callback callback)
	{
        ActionMode actionMode = super.startActionMode(callback);
        return resolveActionMode(actionMode);
    }

    @Override
    public ActionMode startActionMode(ActionMode.Callback callback, int type)
	{
        ActionMode actionMode = super.startActionMode(callback, type);
        return resolveActionMode(actionMode);
    }

    private void releaseAction()
	{
        if (mActionMode != null)
		{
            mActionMode.finish();
            mActionMode = null;
        }
    }

    /**
     * 点击的时候，获取网页中选择的文本，回掉到原生中的js接口
     * @param title 传入点击的item文本，一起通过js返回给原生接口
     */
    private void getSelectedData(String title)
	{

        String js = "(function getSelectedText() {" +
			"var txt;" +
			"var title = \"" + title + "\";" +
			"if (window.getSelection) {" +
			"txt = window.getSelection().toString();" +
			"} else if (window.document.getSelection) {" +
			"txt = window.document.getSelection().toString();" +
			"} else if (window.document.selection) {" +
			"txt = window.document.selection.createRange().text;" +
			"}" +
			"JSInterface.callback(txt,title);" +
			"})()";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
		{
            evaluateJavascript("javascript:" + js, null);
        }
		else
		{
            loadUrl("javascript:" + js);
        }
    }

    public void linkJSInterface()
	{
        addJavascriptInterface(new ActionSelectInterface(this), "JSInterface");
    }

    /**
     * 设置弹出action列表
     * @param actionList
     */
    public void setActionList(List<String> actionList)
	{
        mActionList = actionList;
    }

    /**
     * 设置点击回掉
     * @param actionSelectListener
     */
    public void setActionSelectListener(ActionSelectListener actionSelectListener)
	{
        this.mActionSelectListener = actionSelectListener;
    }

    /**
     * 隐藏消失Action
     */
    public void dismissAction()
	{
        releaseAction();
    }


    /**
     * js选中的回掉接口
     */
    private class ActionSelectInterface
	{

        PrimWebView mContext;

        ActionSelectInterface(PrimWebView c)
		{
            mContext = c;
        }

        @JavascriptInterface
        public void callback(final String value, final String title)
		{
            if (mActionSelectListener != null)
			{
                mActionSelectListener.onClick(title, value);
            }
        }
    }
}
