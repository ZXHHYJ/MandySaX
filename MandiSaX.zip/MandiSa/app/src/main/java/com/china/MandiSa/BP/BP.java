package com.china.MandiSa.BP;


/*
 一个用于判断权重的BP神经网络
 */

public class BP
{
	private static int a1 = 0;
	private static boolean out = true;
	//改了也没有什么用
	public static boolean BP(int[] bp, boolean a)//bp数组1,0，a权重
	{
		if (a)
		{
			com.china.MandiSa.BP.BP.a1 = 1;//true为正数
		}
		else
		{
			com.china.MandiSa.BP.BP.a1 = -1;//false为负数
		}
		for (int j = 0; j < bp.length; j++)
		{
			if (bp[j] == 1)
			{
				a1= a1 + 1;
			}
			else a1 = a1 - 1;
			if (a1 > 0)//检查累积大小
			{
				com.china.MandiSa.BP.BP.out=true;//true数据较多，使用true
			}
			else {
				if(a1==0){
					com.china.MandiSa.BP.BP.out=a;//发现两边相等时使用权重
				}else{
				com.china.MandiSa.BP.BP.out = false;//false数据较多，使用false
				}
			}
		}
		return out;
	}
}

