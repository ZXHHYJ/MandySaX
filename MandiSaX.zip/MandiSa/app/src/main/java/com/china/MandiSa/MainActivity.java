package com.china.MandiSa;

import android.app.*;
import android.content.*;
import android.graphics.drawable.*;
import android.net.*;
import android.os.*;
import android.support.v7.widget.*;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.view.inputmethod.*;
import android.webkit.*;
import android.widget.*;
import com.china.MandiSa.Bug.*;
import com.china.MandiSa.Cc.*;
import com.china.MandiSa.V.*;
import com.china.MandiSa.W.*;
import com.china.MandiSa.X.*;
import com.eightbitlab.supportrenderscriptblur.*;
import eightbitlab.com.blurview.*;
import java.util.*;

import com.china.MandiSa.X.ListAdapter;

public class MainActivity extends Activity
{
    public List<PrimWebView> list_webView = new ArrayList<PrimWebView>();
	static List<ItemBean> mData;
    InputMethodManager imm;
	public static Button button_page,button_pagetop;
	public static ImageView imageButton_menu,ImageButton_menutop,imageButton3,imageButton4;
	public static FrameLayout webViewLayout;
    EditText a;
	RecyclerView mRecyclerView;
	static ListAdapter adapter;
	static AlertDialog mDialog;
	static String url= "file:///android_asset/index.html";
	static String search="https://m.toutiao.com/search/?keyword=";
    public static int currentPage;
	public static MainActivity e;
	public static BlurView b,c;
    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
		e = this;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
		{
			this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
	    //b = findViewById(R.id.mainBlurView1);
		c = findViewById(R.id.mainBlurView2);
		AndroidBug5497Workaround.assistActivity(this);
        webViewLayout = findViewById(R.id.webViewLayout);
        button_page = findViewById(R.id.button_page);
		button_pagetop = findViewById(R.id.button_pagetop);
		imageButton_menu = findViewById(R.id.mainImageButton1);
		ImageButton_menutop = findViewById(R.id.mainImageButton1top);
		imageButton3 = findViewById(R.id.mainImageButton3top);
		imageButton4 = findViewById(R.id.mainImageButton4top);
		button_pagetop.setOnClickListener(new ButtonListener());
        button_page.setOnClickListener(new ButtonListener());
        imageButton_menu.setOnClickListener(new ButtonListener());
		ImageButton_menutop.setOnClickListener(new ButtonListener());
		imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        setupBlurView();
		a = findViewById(R.id.EditEditText2);
		a.setOnEditorActionListener(new TextView.OnEditorActionListener() {

				@Override
				public boolean onEditorAction(TextView arg0, int arg1, KeyEvent arg2)
				{
					if (arg1 == EditorInfo.IME_ACTION_SEARCH || (arg2 != null && arg2.getKeyCode() == KeyEvent.KEYCODE_ENTER && arg2.getAction() == KeyEvent.ACTION_DOWN))
					{
						list_webView.get(currentPage).requestFocus();
						hideSoftInput(a, imm);
						if (TextUtils.isEmpty(a.getText()))
						{	
						}
						else
						{
							if(com.china.MandiSa.W.PrimWebView.isHttpUrl(a.getText().toString())){
							newWindow(a.getText().toString());
							}else newWindow(search + a.getText());
							}
						return true;
					}
					return false;
				}
			});
		if (getIntent().getData() != null)
		{
			Uri uri = getIntent().getData();
            if (uri != null)
			{
				newWindow(uri.toString());
			}
		}
		else
		{
			if (list_webView.size() == 0)
			{
				newWindow(url);
			}
		}
	}

	private void setupBlurView() {
        final float radius = 25f;

        final Drawable windowBackground = getWindow().getDecorView().getBackground();

        c.setupWith(webViewLayout)
			.setFrameClearDrawable(windowBackground)
			.setBlurAlgorithm(new SupportRenderScriptBlur(this))
			.setBlurRadius(radius)
			.setHasFixedTransformationMatrix(true);
			
    }
	
    class ButtonListener implements OnClickListener
	{
        @Override
        public void onClick(View v)
		{
            switch (v.getId())
			{
                case R.id.button_page:
                    seeWindows();
                    break;
				case R.id.button_pagetop:
					seeWindows();
					break;
                case R.id.mainImageButton1:
					PopWindows.a(v);
                    break;
				case R.id.mainImageButton1top:
					PopWindows.a(v);
					break;
            }
        }

		private void seeWindows()
		{
			// TODO: Implement this method
			mRecyclerView = new RecyclerView(MainActivity.this);
			mDialog = new AlertDialog.Builder(MainActivity.this).create();
			mDialog.setView(mRecyclerView);
			mData = new ArrayList<>();

			for (int i = 0 ; i < list_webView.size() ; i++)
			{
				ItemBean ItemBean=new ItemBean();
				ItemBean.title = +i + 1 + "." + list_webView.get(i).getTitle();
				mData.add(ItemBean);
			}

			showList(true, false);
			mDialog.show();

			SelectedNavItem.setSlectedNavItem(currentPage); // 更新选中的位置
			adapter.notifyDataSetChanged();
			if (list_webView.size() == 0)
			{
				mDialog.dismiss();
			}
		}
    }

    @Override
    public void onBackPressed()
	{
		if (list_webView.size() > 0)
		{
			if (list_webView.get(currentPage).canGoBack())
			{
				list_webView.get(currentPage).goBack();
			}
			else 
			{
				if (currentPage - 1 != -1)
				{
					backWindows();
				}
				else
				{
					if (list_webView.size() - 1 == 0)
					{
						exitApp();
					}
					else
					{
						currentPage = list_webView.size() - 1;
						backWindows();
					}
				}
			}
		}
		else exitApp();
	}
	void showList(boolean isVertical, boolean isReverse)
	{
		//创建适配器
		adapter = new ListAdapter(mData, this);
        adapter.setOnItemClickListener(new ListAdapter.OnItemClickListener() {
				@Override
				public void onItemClick(View view, int position)
				{
					SelectedNavItem.setSlectedNavItem(position); // 更新选中的位置
					if (position != currentPage)
					{
						list_webView.get(currentPage).onPause();		
						webViewLayout.removeAllViews();
						WebView webView = list_webView.get(position);
						webViewLayout.addView(webView);
						webView.onResume();
						button_page.setText(list_webView.size() + "");
						currentPage = position;			
					}

					adapter.notifyDataSetChanged();
					mDialog.dismiss();
				}
			});
		//根据条件创建布局管理器
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        //设置布局管理器的属性
        layoutManager.setOrientation(isVertical ?LinearLayoutManager.VERTICAL : LinearLayoutManager.HORIZONTAL);
        layoutManager.setReverseLayout(isReverse);
        //设置布局管理器
        mRecyclerView.setLayoutManager(layoutManager);
        //设置适配器
        mRecyclerView.setAdapter(adapter);
	}

	void onWindows(int which)
	{
		list_webView.get(currentPage).onPause();
		webViewLayout.removeAllViews();
		WebView webView = list_webView.get(which);
		webViewLayout.addView(webView);
		webView.onResume();
		button_page.setText(list_webView.size() + "");
		currentPage = which;
	}

	void backWindows()
	{
		list_webView.remove(currentPage);
		currentPage--;
		if (currentPage < 0) currentPage = 0;
		button_page.setText(list_webView.size() + "");
		webViewLayout.removeAllViews();
		WebView webView = list_webView.get(currentPage);
		webViewLayout.addView(webView);
	}

	public static void overWindows(int a)
	{
		e.list_webView.get(a).onPause();
		e.list_webView.remove(a);
		mData.remove(a);
		if (e.list_webView.size() == 0)
		{
			newWindow(url);
			mDialog.dismiss();
		}
		else
		{
			currentPage--;
			if (currentPage < 0) currentPage = 0;
			button_page.setText(e.list_webView.size() + "");
			webViewLayout.removeAllViews();
			WebView webView = e.list_webView.get(currentPage);
			webViewLayout.addView(webView);
			webView.onResume();
		}
		SelectedNavItem.setSlectedNavItem(currentPage); // 更新选中的位置
		adapter.notifyDataSetChanged();
		mDialog.dismiss();
	}

	boolean isNetworkConnected()
	{
        ConnectivityManager mConnectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
        if (mNetworkInfo != null)
		{
            return mNetworkInfo.isAvailable();
        }
        return false;
    }

    static void newWindow(String surl)
	{
        PrimWebView webView = new PrimWebView(e.getApplication());
        webView.loadUrl(surl);
        webViewLayout.removeAllViews();
        webViewLayout.addView(webView);
        e.list_webView.add(webView);
        currentPage = e.list_webView.size() - 1;
        button_page.setText(e.list_webView.size() + "");
    }
	
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode)
		{
			case com.china.MandiSa.W.PrimWebView.REQUEST_CODE_LOLIPOP:
                Uri[] results = null;
                // Check that the response is a good one
                if (resultCode == Activity.RESULT_OK)
				{
                    if (data == null)
					{
                        // If there is not data, then we may have taken a photo
                        if (com.china.MandiSa.W.PrimWebView.a.mCameraPhotoPath != null)
						{

                            results = new Uri[]{Uri.parse(com.china.MandiSa.W.PrimWebView.a.mCameraPhotoPath)};
                        }
                    }
					else
					{
                        String dataString = data.getDataString();
                        if (dataString != null)
						{
                            results = new Uri[]{Uri.parse(dataString)};
                        }
                    }
                }

                com.china.MandiSa.W.PrimWebView.a.mFilePathCallback.onReceiveValue(results);
				com.china.MandiSa.W.PrimWebView.a.mFilePathCallback = null;
                break;
        }
    }

	public static void showInput(final EditText et, InputMethodManager imm)
	{
        et.requestFocus();
        imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
    }

	private static void hideSoftInput(final EditText a, InputMethodManager imm)
	{

		imm.hideSoftInputFromWindow(a.getWindowToken(), 0);

	}

	@Override
	protected void onNewIntent(Intent intent)
	{		
		super.onNewIntent(intent);
	    setIntent(intent);
		if (intent.getData() != null)
		{
			newWindow(intent.getData() + "");
		}
	}

	@Override
    protected void onPause()
	{
		if (list_webView != null)
		{
			for (int j = 0; j < list_webView.size(); j++)
			{
				list_webView.get(j).onPause();
				list_webView.get(j).pauseTimers();
			}
		}
		super.onPause();
    }

    @Override
    protected void onResume()
	{
		if (list_webView != null)
		{
			for (int j = 0; j < list_webView.size(); j++)
			{
				list_webView.get(j).resumeTimers();
				list_webView.get(j).onResume();
			}
		}
        super.onResume();
    }

	@Override
	protected void onDestroy()
	{
		if (list_webView != null)
		{
			for (int j = 0; j < list_webView.size(); j++)
			{
				list_webView.get(j).removeAllViews();
				list_webView.get(j).destroy();
			}
		}
		super.onDestroy();
	}

	long[] mHits = new long[2];
    //定义一个所需的数组
    private void exitApp()
	{
		//数组向左移位操作
        System.arraycopy(mHits, 1, mHits, 0, mHits.length - 1);
        mHits[mHits.length - 1] = SystemClock.uptimeMillis();
        if (mHits[0] >= (SystemClock.uptimeMillis() - 1600))
		{
			e.finish();
		}
		else
		{
			ToastUtil.getInstance().showToast("再按一次退出", getApplicationContext());
        }
    }

}

