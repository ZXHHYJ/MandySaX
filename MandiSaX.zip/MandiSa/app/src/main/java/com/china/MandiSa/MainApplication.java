package com.china.MandiSa;

import android.app.*;
import com.china.MandiSa.Bug.*;
import com.china.MandiSa.Cc.*;

public class MainApplication extends Application
{

    @Override
    public void onCreate()
	{
        super.onCreate();
		ToastUtil.init(MainApplication.this);
        ExceptionHandler.getInstance(MainApplication.this).init();
    }
}
