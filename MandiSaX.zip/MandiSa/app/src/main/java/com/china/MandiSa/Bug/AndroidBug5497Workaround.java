package com.china.MandiSa.Bug;

import android.app.*;
import android.content.res.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.Cc.*;

/**
 * 解决WebView中输入时弹出软键盘，挡住输入框的问题
 * copy from https://www.jianshu.com/p/306482e17080
 * Created by ldw on 2018/5/23.
 */

public class AndroidBug5497Workaround
{    
	public static void assistActivity(Activity activity)
	{      
		new AndroidBug5497Workaround(activity);   
	}  
	public static AndroidBug5497Workaround q;
	private View mChildOfContent;   
	private int usableHeightPrevious;  
	private FrameLayout.LayoutParams frameLayoutParams;  
	private int contentHeight;  
	private   boolean isfirst = true;  
    private	boolean keyboard=false;
	private   Activity activity; 
	private  int statusBarHeight;  

	private AndroidBug5497Workaround(Activity activity)
	{      
		//获取状态栏的高度    
		q=this;
		int resourceId = activity.getResources().getIdentifier("status_bar_height", "dimen", "android");        
		statusBarHeight = activity.getResources().getDimensionPixelSize(resourceId);      
		this.activity = activity;
		FrameLayout content = activity.findViewById(android.R.id.content);        
		mChildOfContent = content.getChildAt(0);   

		//界面出现变动都会调用这个监听事件        
		mChildOfContent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {           
				public void onGlobalLayout()
				{              
					if (isfirst)
					{ 
						if (ifLCD())
						{
							contentHeight = mChildOfContent.getHeight();//兼容华为等机型   
						}
						else contentHeight = mChildOfContent.getWidth();
						isfirst = false;  
					}               
					possiblyResizeChildOfContent();         
				}      
			});     

		frameLayoutParams = (FrameLayout.LayoutParams)     
			mChildOfContent.getLayoutParams();    
	} 

	//重新调整跟布局的高度 
	private void possiblyResizeChildOfContent()
	{  

		int usableHeightNow = computeUsableHeight();       

		//当前可见高度和上一次可见高度不一致 布局变动      
		if (usableHeightNow != usableHeightPrevious)
		{           
			int usableHeightSansKeyboard=0;
			int ifLCD=2;
			//int usableHeightSansKeyboard2 = mChildOfContent.getHeight();//兼容华为等机型
			if (ifLCD())
			{
				usableHeightSansKeyboard = mChildOfContent.getRootView().getHeight();   
				ifLCD = 4;
			}
			else
			{
				usableHeightSansKeyboard = mChildOfContent.getRootView().getWidth();
				ifLCD = 2;
			} 
			int heightDifference = usableHeightSansKeyboard - usableHeightNow;          
			if (heightDifference > (usableHeightSansKeyboard / ifLCD))
			{          
				// keyboard probably just became visible        
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
				{                    
					//frameLayoutParams.height = usableHeightSansKeyboard - heightDifference;                    
					frameLayoutParams.height = usableHeightSansKeyboard - heightDifference + statusBarHeight;
					if (ifLCD())
					{
						com.china.MandiSa.MainActivity.c.setVisibility(View.GONE);
						keyboard=true;
					}
				}
				else
				{                
					frameLayoutParams.height = usableHeightSansKeyboard - heightDifference;
					if (ifLCD())
					{
						com.china.MandiSa.MainActivity.c.setVisibility(View.GONE);
						keyboard=true;
					}
				}            
			}
			else
			{     
				//ToastUtil.getInstance().showToast(ifLCD()+"",activity.getApplicationContext());
				frameLayoutParams.height = contentHeight;
				if (ifLCD())
				{
					if (activity.isInMultiWindowMode() == false)
					{
						//ToastUtil.getInstance().showToast("1",activity.getApplicationContext());
						com.china.MandiSa.MainActivity.c.setVisibility(View.VISIBLE);
						com.china.MandiSa.MainActivity.ImageButton_menutop.setVisibility(View.GONE);
						com.china.MandiSa.MainActivity.imageButton3.setVisibility(View.GONE);
						com.china.MandiSa.MainActivity.imageButton4.setVisibility(View.GONE);
						com.china.MandiSa.MainActivity.button_pagetop.setVisibility(View.GONE);
						keyboard=false;
					}
				}
				else
				{
					//ToastUtil.getInstance().showToast("2",activity.getApplicationContext());
					com.china.MandiSa.MainActivity.c.setVisibility(View.GONE);
					com.china.MandiSa.MainActivity.ImageButton_menutop.setVisibility(View.VISIBLE);
					com.china.MandiSa.MainActivity.imageButton3.setVisibility(View.VISIBLE);
					com.china.MandiSa.MainActivity.imageButton4.setVisibility(View.VISIBLE);
					com.china.MandiSa.MainActivity.button_pagetop.setVisibility(View.VISIBLE);
					keyboard=true;
				}
			}   

			mChildOfContent.requestLayout();       
			usableHeightPrevious = usableHeightNow;    
		}  
	}   
	/**     * 计算mChildOfContent可见高度     ** @return     */    
	private int computeUsableHeight()
	{  
		Rect r = new Rect();     
		mChildOfContent.getWindowVisibleDisplayFrame(r);       
		return (r.bottom - r.top);  
	}

	public static boolean ifLCD()
	{
		boolean a = true;
		Configuration mConfiguration = com.china.MandiSa.MainActivity.e.getResources().getConfiguration(); //获取设置的配置信息
		int ori = mConfiguration.orientation; //获取屏幕方向
		if (ori == mConfiguration.ORIENTATION_LANDSCAPE)
		{
			//横屏
			a = false;
		}
		else if (ori == mConfiguration.ORIENTATION_PORTRAIT)
		{
			//竖屏
			a = true;
		}
		return a;
	}
	
	public static boolean ifKeyboard(){
		return q.keyboard;
	}
}
