package com.china.MandiSa.Cc;

import android.content.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.*;

public class ToastUtil
{

	private  Context mContext; // 上下文对象

	private ToastUtil()
	{} // 私有化构造

	private static final class Helper
	{ // 内部帮助类，实现单例
		static final ToastUtil INSTANCE = new ToastUtil();
	}

	public static ToastUtil getInstance()
	{ // 获取单例对象
		return Helper.INSTANCE;
	}

	public static void init(Context context)
	{ // 初始化Context
		Helper.INSTANCE.mContext = context;
	}

	public void showToast(CharSequence text, Context context)
	{ // 根据字符串弹Toast
		if (mContext == null)
		{
		}else{
			LayoutInflater inflate = (LayoutInflater)
			context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View layout = inflate.inflate(R.layout.toast, null);
				TextView tvMsg = layout.findViewById((R.id.ConText));
				tvMsg.setText(text);
				Toast toast = new Toast(context.getApplicationContext());
				toast.setDuration(Toast.LENGTH_SHORT);
				toast.setView(layout);
				toast.show();
		}
	}
}
