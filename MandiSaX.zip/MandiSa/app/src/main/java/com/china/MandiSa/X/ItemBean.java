package com.china.MandiSa.X;

public class ItemBean
{
	public String title;
}
