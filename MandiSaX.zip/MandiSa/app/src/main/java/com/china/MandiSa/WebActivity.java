package com.china.MandiSa;
import android.app.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.*;
import com.china.MandiSa.V.*;
import com.china.MandiSa.X.*;
import com.eightbitlab.supportrenderscriptblur.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.net.*;

import com.china.MandiSa.V.Toolbar;

public class WebActivity extends Activity
{
    private TextView t1;
	private ProgressDialog progress;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
    	if (com.china.MandiSa.W.PrimWebView.isDayTheme)
		{
			setTheme(R.style.AppTheme);
		}
		else setTheme(R.style.NightTheme);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
		{
			this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web);
		Toolbar.set(this,"网页源码");
		t1 = findViewById(R.id.webTextView1);
		progress = new ProgressDialog(this);
		try
		{
			final String url_str = com.china.MandiSa.MainActivity.e.list_webView.get(com.china.MandiSa.MainActivity.e.currentPage).getUrl().toString().trim();
			progress.setMessage("正在加载网页...");
			progress.show();
			new Thread(new Runnable() {
					@Override
					public void run()
					{
						try
						{
							URL url = new URL(url_str);
							HttpURLConnection connection = (HttpURLConnection) url.openConnection();
							connection.setRequestMethod("GET");
							connection.setConnectTimeout(5 * 1000);
							int code = connection.getResponseCode();
							if (code == 200)
							{
								InputStream inputStream = connection.getInputStream();
								String results = StreamUtils.streanTosting(inputStream);
								Message msg = new Message();
								msg.obj = results;
								handler.sendMessage(msg);						
							}
						}
						catch (Exception e)
						{
							e.printStackTrace();
							progress.dismiss();
							finish();
						}
					}
				}).start();
		}
		catch (Exception e)
		{
			progress.dismiss();
			finish();
		}
	}
    private Handler handler = new Handler(){
        public void handleMessage(android.os.Message msg)
		{
            String result  = (String) msg.obj;
			t1.setText(result);
			progress.dismiss();
        };
    };
}
