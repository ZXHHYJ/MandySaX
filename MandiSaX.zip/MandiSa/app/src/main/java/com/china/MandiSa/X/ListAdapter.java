package com.china.MandiSa.X;

import android.content.*;
import android.graphics.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.*;
import java.util.*;
import com.china.MandiSa.Cc.*;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder>
{
    private Context mContext;
    private List<ItemBean> mLists;


    public ListAdapter(List<ItemBean> lists,Context context)
	{
        mLists = lists;
		mContext=context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
	{
        if (mContext == null)
		{
            mContext = parent.getContext();
        }
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_list, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position)
	{
        ItemBean func = mLists.get(position);
        holder.Name.setText(func.title);
		/*设置选中状态*/
        if (position == SelectedNavItem.getSlectedNavItem())
		{
            holder.Name.setTextColor(Color.parseColor("#FFFF5700"));
	    }
		else
		{
			holder.Name.setTextColor(Color.parseColor("#FF000000"));
		}
        holder.Xxxx.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					com.china.MandiSa.MainActivity.overWindows(position);
				}
			});
		
        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					onItemClickListener.onItemClick(holder.itemView, position);
				}
			});
    }

    @Override
    public int getItemCount()
	{
        return mLists.size();

    }

    private OnItemClickListener onItemClickListener = null;

    public void setOnItemClickListener(OnItemClickListener listener)
	{
        onItemClickListener = listener;
    }


    public interface OnItemClickListener
	{
        void onItemClick(View view, int position);
    }


    public class ViewHolder extends RecyclerView.ViewHolder
	{
		TextView Name;
		TextView Xxxx;
        public ViewHolder(View itemView)
		{
            super(itemView);
		    Name = itemView.findViewById(R.id.title);
			Xxxx = itemView.findViewById(R.id.xxxx);
			
		}
    }
}
