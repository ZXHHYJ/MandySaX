package com.china.MandiSa.Bug;

import android.app.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.*;
import com.china.MandiSa.V.*;
import com.eightbitlab.supportrenderscriptblur.*;
import eightbitlab.com.blurview.*;
import java.io.*;

import com.china.MandiSa.V.Toolbar;

public class BugActivity extends Activity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
		{
			this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_bug);
		Toolbar.set(this,"错误信息");
        try
		{
            TextView TV = findViewById(R.id.bug);
            Object obj = getIntent().getSerializableExtra("bug");
            Throwable error = (Throwable) obj;
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            assert error != null;
            error.printStackTrace(pw);
            TV.setText(sw.toString());
        }
		catch (Throwable e)
		{
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }


}
