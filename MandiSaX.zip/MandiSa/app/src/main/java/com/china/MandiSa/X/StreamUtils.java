package com.china.MandiSa.X;

import java.io.*;

/**
 * Created by kevin on 2017/3/22.
 */
public class StreamUtils {
    public static String streanTosting(InputStream inputStream){
        String result = "";//保存字符串
        try {
            //进行流的读写
            byte[] buffer = new byte[1024 * 8];
            //创建一个写到内存的字节数组输出流
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int len;
            while ((len = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer,0,len);
                byteArrayOutputStream.flush();//不断的刷新缓存
            }
            byteArrayOutputStream.close();//进行关闭流通道
            result = byteArrayOutputStream.toString();//将写入的字节流转化为字符串
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }
}
