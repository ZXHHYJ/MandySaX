package com.china.MandiSa;

import android.app.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.V.*;
import com.eightbitlab.supportrenderscriptblur.*;
import eightbitlab.com.blurview.*;

import com.china.MandiSa.V.Toolbar;
public class GeneralActivity extends Activity
{
	private CheckBox c1,c2,c3,c4,c5;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		if (com.china.MandiSa.W.PrimWebView.isDayTheme)
		{
			setTheme(R.style.AppTheme);
		}
		else setTheme(R.style.NightTheme);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
		{
			this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
		super.onCreate(savedInstanceState);
		setContentView(R.layout.generals);
		Toolbar.set(this,"通用");
		c1 = findViewById(R.id.generalsCheckBox1);
		c2 = findViewById(R.id.generalsCheckBox2);
		c3 = findViewById(R.id.generalsCheckBox3);
		c4 = findViewById(R.id.generalsCheckBox4);
		c5 = findViewById(R.id.generalsCheckBox5);
		//c1.setChecked(com.FMJJ.MandySa.X5.X5WebView.);
		c2.setChecked(com.china.MandiSa.W.PrimWebView.isJs);
		c3.setChecked(com.china.MandiSa.W.PrimWebView.isGps);
		c4.setChecked(com.china.MandiSa.W.PrimWebView.isDom);
		c5.setChecked(com.china.MandiSa.W.PrimWebView.isImg);
    	c1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					
				}
			});
    	c2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					com.china.MandiSa.MainActivity.e.list_webView.get(com.china.MandiSa.MainActivity.e.currentPage).isJs();
				}
			});
    	c3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					com.china.MandiSa.MainActivity.e.list_webView.get(com.china.MandiSa.MainActivity.e.currentPage).isGps();
				}
			});
    	c4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					com.china.MandiSa.MainActivity.e.list_webView.get(com.china.MandiSa.MainActivity.e.currentPage).isDom();
				}
			});
    	c5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					com.china.MandiSa.MainActivity.e.list_webView.get(com.china.MandiSa.MainActivity.e.currentPage).isImg();
				}
			});
	}
}
