package com.china.MandiSa.Cc;

import android.content.*;
import android.text.*;
import android.text.ClipboardManager;

public class copy
{
	public static void copy(String Text,Context Activity){
	ClipboardManager cm = (ClipboardManager) Activity.getSystemService(Context.CLIPBOARD_SERVICE);
    cm.setText(Text);
	}
}
