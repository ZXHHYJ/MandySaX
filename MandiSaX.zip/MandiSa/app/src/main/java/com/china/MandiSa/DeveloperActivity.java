package com.china.MandiSa;

import android.app.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.BP.*;
import com.china.MandiSa.Cc.*;
import com.china.MandiSa.V.*;
import com.eightbitlab.supportrenderscriptblur.*;
import eightbitlab.com.blurview.*;

import com.china.MandiSa.V.Toolbar;

public class DeveloperActivity extends Activity 
{
	private Button b1;
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
		if (com.china.MandiSa.W.PrimWebView.isDayTheme)
		{
			setTheme(R.style.AppTheme);
		}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
		{
			this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
		else setTheme(R.style.NightTheme);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.developer);
		Toolbar.set(this,"开发者模式");
		b1 = findViewById(R.id.developerButton1);
		b1.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View view)
				{
					int[] a ={1,1,1,1,1,1,0,0,0,0};

					ToastUtil.getInstance().showToast("" + BP.BP(a, false), getApplicationContext());
				}
			});
	}
}
