package com.china.MandiSa.W;
/**
 * Created by guoshuyu on 2017/6/17.
 */

public interface ActionSelectListener {
    void onClick(String title, String selectText);
}
