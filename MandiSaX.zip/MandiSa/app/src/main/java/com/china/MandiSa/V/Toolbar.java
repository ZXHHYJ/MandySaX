package com.china.MandiSa.V;

import android.app.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import com.china.MandiSa.*;
import com.eightbitlab.supportrenderscriptblur.*;
import eightbitlab.com.blurview.*;

public class Toolbar
{
	public static void set(final Activity a,String b)
	{
		a.setTitle(b);
		TextView Title = a.findViewById(R.id.toolbarTextView1);
		ImageView back = a.findViewById(R.id.toolbarImageButton1);
		back.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view)
				{
					a.finish();
				}
			});
		Title.setText(a.getTitle());
	}
}
