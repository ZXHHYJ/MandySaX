package com.china.MandiSa.X;

public class MessageEvent
{
}